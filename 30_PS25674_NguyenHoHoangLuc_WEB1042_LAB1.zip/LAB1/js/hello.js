alert('Welcome to FPT Polytechnic')
document.write('<h1>The first JavaScript App</h1>')